/* 
 * File:   main.cpp
 * Author: Valentinno Cruz
 * Created on June 22, 2020, 3:02 PM
 * Purpose: Hello World
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here


//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions


//Function Prototypes Here


//Program Execution Begins Here
int main(int argc, char** argv) {
    
    
    //Declare all Variables Here
    cout <<"Hello World!";
            
    //Input or initialize values Here
   
    
    
    //Process/Calculations Here
    
    
    
    //Output Located Here
   
    
    //Exit
    return 0;
}

